
package es.sauces.banco;

import java.util.LinkedList;
import java.util.List;

/**
 * La clase {@code Banco} modela las diferentes acciones que pueden hacerse con una cuenta.
 * @author irene.rodrod.2
 * @since 2.0
 */

public class Banco {
    private String nombre;
    private List<Cuenta> cuentas;

    /**
     * 
     * @param nombre 
     */
    public Banco(String nombre) {
        this.nombre = nombre;
        cuentas=new LinkedList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Cuenta> getCuentas() {
        return cuentas;
    }
    
    /**
     * Devuelve los valores de la nueva cuenta generada 
     * @param cuenta
     * @return cuentaAbierta - En caso de que sea verdadera, sino devolverá un error
     */
    public boolean abrirCuenta(Cuenta cuenta){
        if(buscarCuenta(cuenta.getCodigo())==null){
            return cuentas.add(cuenta);
        }
        return false;
        
        /*boolean cuentaAbierta = false;
        if(!cuentas.contains(cuenta)){
            cuentas.add(cuenta); 
        }else {
            return false;
        }
        return cuentaAbierta;
        */
    }
    
    /**
     * 
     * @param codigo
     * @return 
     */
    public Cuenta buscarCuenta(String codigo){
        int posicion=cuentas.indexOf(new Cuenta(codigo));
        if(posicion!=-1){
            return cuentas.get(posicion);
        }
        return null;
        
        /*Cuenta cuentaABuscar=new Cuenta(nombre);
        if(cuentas.contains(cuentaABuscar)){
            cuentas.indexOf(codigo);
        } 
        return cuentaABuscar;*/
        
        //return cuentas.indexOf(new Cuenta(codigo));

        // return cuentas.getCuenta(cuentaABuscar)); //no se puede pq es del tipo int y estamos bucando un String
    }

    /**
     * 
     * @param codigo
     * @return 
     */
    public boolean cancelarCuenta(String codigo){
        return cuentas.remove(Cuenta);
        
        
        /*boolean cuentaCancelada=false;
        Cuenta cuentaAEliminar=new Cuenta(nombre);
        if(cuentas.contains(cuentaAEliminar)){
           cuentas.remove(cuentaAEliminar);
           cuentaCancelada=true;
       }
       return cuentaCancelada;*/
    }
    
    /**
     * 
     * @return 
     */
    public float getTotalDepositos(){
        float acumulador=0;
        
        for(Cuenta c:cuentas){
            acumulador+=c.getSaldo();
        }
        return acumulador;
    }
}
