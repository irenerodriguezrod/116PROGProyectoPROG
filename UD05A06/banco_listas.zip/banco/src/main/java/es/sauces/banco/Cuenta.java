package es.sauces.banco;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * La clase {@code Cuenta} modela una cuenta bancaria.
 * @author irene.rodrod.2
 * @since 1.0
 */

public abstract class Cuenta implements Comparable{
    private String codigo;
    private String titular;
    private float saldo;
    private List<Movimiento> movimientos;

    public Cuenta() {
        movimientos=new ArrayList<>();
    }

    public Cuenta(String codigo) {
        this.codigo = codigo;
        movimientos=new ArrayList<>();
    }

    
    /**
     * Permite instaciar un objeto incializando los valores codigo, titular y salida
     * @param codigo    el codigo de la cuenta
     * @param titular   el DNI del titular de la cuenta
     * @param saldo     el saldo de la cuenta
     */
    public Cuenta(String codigo, String titular, float saldo) {
        this.codigo = codigo;
        this.titular = titular;
        if(saldo>0){
            this.saldo = saldo;
        }
        movimientos=new ArrayList<>();
    }

    /**
     * Devuelve el codigo de la cuenta
     * @return el codigo de la cuenta
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     *
     * @return
     */
    public String getTitular() {
        return titular;
    }

    /**
     *
     * @return
     */
    public float getSaldo() {
        return saldo;
    }

    /**
     * 
     * @return 
     */
    public List<Movimiento> getMovimientos() {
        return movimientos;
    }
    
    /**
     * Sirve para buscar los movimientos que se han realizado entre dos fechas.
     * 
     * @param desde fecha de inicio de los movimientos que estamos buscando
     * @param hasta fecha final de la busqueda de los movimientos que hemos realizado
     * @return 
     */
    public List<Movimiento> getMovimientos(LocalDate desde, LocalDate hasta){
        List<Movimiento> listado =new ArrayList<>();
        return listado;
    }

    /**
     *
     * @param codigo
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     *
     * @param titular
     */
    public void setTitular(String titular) {
        this.titular = titular;
    }

    /**
     *
     * @param saldo
     */
    public void setSaldo(float saldo) {
        if (saldo>=0){
            this.saldo=saldo;
        }
        this.saldo = saldo;
    }

    /**
     *
     * @param cantidad
     */
    public void ingresar(float cantidad){
        if(cantidad>0){
            saldo+=cantidad;
            movimientos.add(new Movimiento(LocalDate.now(),'I',cantidad,saldo));
        }
    }

    /**
     *
     * @param cantidad
     */
    public void reintegrar(float cantidad){
        if(cantidad>0 && cantidad<=saldo){
            saldo-=cantidad;
            movimientos.add(new Movimiento(LocalDate.now(),'R',-cantidad,saldo));
        }
    }
    
    /**
     * Sirve para poder hacer movimientos entre diferentes cuentas. 
     * @param destino   cuenta a la que se va a enviar el dinero
     * @param cantidad  cantidad que va a ser enviada 
     */
    public void realizarTransferencia(Cuenta destino, float cantidad){
        if(destino!=null && destino!=this){ //se comprueba que la cuenta exista y que no se haga a la misma cuenta desde la que se está haciendo la transferencia
            if(cantidad>0 && cantidad<=saldo){
            saldo-=cantidad;
            movimientos.add(new Movimiento(LocalDate.now(),'T',-cantidad,saldo));
            destino.recibirTransferencia(this, cantidad);
            }
        }
    }
    
    public void recibirTransferencia(Cuenta origen, float cantidad){
        if(cantidad>0){
            saldo+=cantidad;
            movimientos.add(new Movimiento(LocalDate.now(),'I',cantidad,saldo));
        }
    }
    
    public String listarMovimientos(){
        return movimientos.toString();
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return  codigo + "," + titular + "," + saldo ;
    }

    /**
     *
     * @return
     */
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 43 * hash + Objects.hashCode(this.codigo);
        return hash;
    }

    /**
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cuenta other = (Cuenta) obj;
        return Objects.equals(this.codigo, other.codigo);
    }
    
    @Override
    public int compareTo(Cuenta o){
        return this.codigo.compareTo(o.codigo);
    }

}
